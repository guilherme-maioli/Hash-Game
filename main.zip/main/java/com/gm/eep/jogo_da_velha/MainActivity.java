package com.gm.eep.jogo_da_velha;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
    private Button[] arrayButton = new Button[10];
    private String vez = "X";
    private int jogadas = 0;
    private String[] matriz = new String[10];


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicializarButtons();
        OnClickButtons();


        Button button= (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ultimoRes();
            }
        });
    }

    private void inicializarButtons(){
        arrayButton[1] = (Button) findViewById(R.id.button1);
        arrayButton[2] = (Button) findViewById(R.id.button2);
        arrayButton[3] = (Button) findViewById(R.id.button3);
        arrayButton[4] = (Button) findViewById(R.id.button4);
        arrayButton[5] = (Button) findViewById(R.id.button5);
        arrayButton[6] = (Button) findViewById(R.id.button6);
        arrayButton[7] = (Button) findViewById(R.id.button7);
        arrayButton[8] = (Button) findViewById(R.id.button8);
        arrayButton[9] = (Button) findViewById(R.id.button9);
    }

    private void OnClickButtons() {
        for(int x=1; x<10; x++){
            final int finalX = x;
            arrayButton[x].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    jogada(finalX);
                }
            });
            matriz[x]="";
        }

    }

    private void jogada(int x){
        if(matriz[x]== ""){
            matriz[x]= vez;
            jogadas++;
            if (vez == "X"){
                vez = "O";
            } else {
                vez = "X";
            }
        }
        exibirButtons();
        verifica();
    }

    private void exibirButtons(){
        for(int x=1; x<10; x++){
            arrayButton[x].setText(matriz[x]);

        }
    }

    private void verifica(){
        if(matriz[1].equals(matriz[2]) && matriz[1].equals(matriz[3]) && matriz[1].toString() != "" ) {
            ganhador(matriz[1]);
            return;
        }
        if(matriz[2].equals(matriz[5]) && matriz[2].equals(matriz[8]) && matriz[2].toString() != "" ) {
            ganhador(matriz[2]);
            return;
        }
        if(matriz[3].equals(matriz[6]) && matriz[3].equals(matriz[9]) && matriz[3].toString() != "" ) {
            ganhador(matriz[3]);
            return;
        }
        if(matriz[1].equals(matriz[5]) && matriz[1].equals(matriz[9]) && matriz[1].toString() != "" ) {
            ganhador(matriz[1]);
            return;
        }
        if(matriz[3].equals(matriz[5]) && matriz[3].equals(matriz[7]) && matriz[3].toString() != "" ) {
            ganhador(matriz[3]);
            return;
        }
        if(matriz[4].equals(matriz[5]) && matriz[4].equals(matriz[6]) && matriz[4].toString() != ""){
            ganhador(matriz[4]);
            return;
        }
        if(matriz[7].equals(matriz[8]) && matriz[7].equals(matriz[9]) && matriz[7].toString() != ""){
            ganhador(matriz[7]);
            return;
        }
        if(matriz[1].equals(matriz[4]) && matriz[1].equals(matriz[7]) && matriz[1].toString() != "" ) {
            ganhador(matriz[1]);
            return;
        }

        if(jogadas == 9){
            ganhador("");
        }
    }

    private void ganhador(String ganhador) {
        String resultado = "";
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Resultado:");
        if (ganhador.equals("")){
            resultado = "Empate";
        } else{
            if(ganhador.equals("X")) {
                resultado = "\"X\" é o vencedor";
            } else {
                resultado = "\"O\" é o vencedor";
            }
        }
        gravar(resultado);
        builder.setMessage(resultado);
        builder.setPositiveButton("Novo jogo", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                jogadas = 0;
                for(int x=1; x<10; x++){
                    matriz[x]="";
                }
                exibirButtons();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    public void gravar (String data) {
        String result = data + "\n";
        try {
            FileOutputStream fOut = openFileOutput ( "result.txt" , Context.MODE_PRIVATE ) ;
            OutputStreamWriter osw = new OutputStreamWriter( fOut ) ;
            osw.write(result) ;
            osw.flush();
            osw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void ultimoRes(){
        try{
            FileInputStream fis = openFileInput("result.txt");
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader bufferedReader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                //line = "";
                sb.append(line);
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Ultimo Resultado:");
            builder.setMessage(sb);
            AlertDialog alert = builder.create();
            alert.show();
        } catch (Exception e) {
           e.printStackTrace();
        }
    }




}
